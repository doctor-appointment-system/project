import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators} from '@angular/forms';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-selectdoctor',
  templateUrl: './selectdoctor.component.html',
  styleUrls: ['./selectdoctor.component.css']
})
export class SelectdoctorComponent implements OnInit {
resData;
data;
show;

myForm:FormGroup;

constructor(private dser:DoctorserviceService,private ar:ActivatedRoute,private fb:FormBuilder) { }

showdoctor(){
  this.show="abc";
  let formData=this.myForm.getRawValue();
  console.log(formData.day);
  localStorage.setItem('day',formData.day);
  localStorage.setItem('month',formData.month);
  localStorage.setItem('year',formData.year);
        
   if (this.show!=undefined){
    console.log(this.show);
    this.ar.params.subscribe(par=>{
      this.dser.fetchDoctor(par.hname).subscribe(res=>{
        this.resData=res;
        console.log(this.resData);
        if(this.resData.err==0){
          this.data=this.resData.ddata;
        }
      })
    })
   
  }
}

  ngOnInit() {
   this.validate();
  }

 validate()
  {
    this.myForm=this.fb.group(
      {
        'day':['',Validators.required],
        'month':['',Validators.required],
        'year':['',Validators.required]
      }
    )
  }


}
