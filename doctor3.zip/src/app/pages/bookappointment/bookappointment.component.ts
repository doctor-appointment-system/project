import { Component, OnInit } from '@angular/core';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';
@Component({
  selector: 'app-bookappointment',
  templateUrl: './bookappointment.component.html',
  styleUrls: ['./bookappointment.component.css']
})
export class BookappointmentComponent implements OnInit {
resData;
data;
  constructor(private dser:DoctorserviceService) { }


  ngOnInit() {

  this.dser.showHospital()
  	.subscribe(res=>{
  		this.resData=res;
  		this.data=this.resData.ddata;

  	})
  }
  }

