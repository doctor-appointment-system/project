import { Component, OnInit } from '@angular/core';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-myappointment',
  templateUrl: './myappointment.component.html',
  styleUrls: ['./myappointment.component.css']
})
export class MyappointmentComponent implements OnInit {
resData;
user;
data;
  constructor(private dser:DoctorserviceService) { }


  deleted(id){

   this.user=localStorage.getItem('patientid');
   
   this.dser.deleted1({'id':id,'user':this.user})
   .subscribe(res=>{

    this.user=localStorage.getItem('patientid');
  	console.log(this.user);

  	this.dser.myappointment(this.user)
  	.subscribe(res=>{
  		this.resData=res;
  		this.data=this.resData.data;

  	})

   })

  }

  ngOnInit() {

  	this.user=localStorage.getItem('patientid');
  	console.log(this.user);

  	this.dser.myappointment(this.user)
  	.subscribe(res=>{
  		this.resData=res;
  		this.data=this.resData.data;

  	})
  }

}
