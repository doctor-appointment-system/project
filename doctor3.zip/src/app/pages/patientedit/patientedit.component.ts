import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators} from '@angular/forms';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';
import {Router} from '@angular/router';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-patientedit',
  templateUrl: './patientedit.component.html',
  styleUrls: ['./patientedit.component.css']
})
export class PatienteditComponent implements OnInit {
myForm:FormGroup;
  constructor(private fb:FormBuilder ,private lser:DoctorserviceService, private router:Router,private ar:ActivatedRoute) { }

did;
e1id;
resData;

myImage;
user;
url;
defaultProfileimg;


editprofile(){
	let formData=this.myForm.getRawValue();
	this.e1id=localStorage.getItem('patientid');

	this.lser.editpatient(formData,this.e1id)
	.subscribe(res=>{
		this.resData=res;
		console.log(this.resData);
		this.router.navigate(['/patientprofile']);
	})
}


detectFiles(event){


  let files=event.target.files;
  
  if (files){
    for (let file of files){
      let reader=new FileReader();
      reader.onload = (e:any)=>{
        this.url=e.target.result;
        this.defaultProfileimg=this.url;
this.user=localStorage.getItem('patientid');
         let data={
          user:this.user,
          img:this.url
        }

        this.lser.upload(data)
        .subscribe(res=>{
           this.router.navigate(['/patientprofile']);
        })
}
      
      reader.readAsDataURL(file);
    }
  }

}


  ngOnInit() {
     this.validate();
     this.e1id=localStorage.getItem('patientid');

  	 this.ar.params.subscribe(par=>
      {
        this.did=par.eid;
        this.lser.fetchpatientById(this.did)
        .subscribe(res=>
          {
         this.resData=res;
         this.myForm.patchValue(this.resData.cdata[0])
          })
      })
  }

   validate()
  {
    this.myForm=this.fb.group(
      {
        'name':['',Validators.required],
        'age':['',Validators.required],
        'mobile':['',Validators.required],
        'address':['',Validators.required]
      }
    )
  }

}
