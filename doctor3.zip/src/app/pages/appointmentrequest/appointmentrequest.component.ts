import { Component, OnInit } from '@angular/core';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';

@Component({
  selector: 'app-appointmentrequest',
  templateUrl: './appointmentrequest.component.html',
  styleUrls: ['./appointmentrequest.component.css']
})
export class AppointmentrequestComponent implements OnInit {
id;

resData;
data;
doctorid;
patientid;
time;
date;
user;
abc;

  constructor(private dser:DoctorserviceService) { }


  accept(id){
    

    this.user=localStorage.getItem('doctorid');

    this.dser.accept({'id':id,'user':this.user})
    .subscribe(res=>{
          
          this.id=localStorage.getItem('doctorid');
    this.dser.request(this.id)
    .subscribe(res=>{
      this.resData=res;
      this.data=this.resData.data;
      console.log(this.data);
    })
         
          
    })
  }

  deleted(id){

   this.user=localStorage.getItem('doctorid');
   
   this.dser.deleted({'id':id,'user':this.user})
   .subscribe(res=>{

     this.id=localStorage.getItem('doctorid');
    this.dser.request(this.id)
    .subscribe(res=>{
      this.resData=res;
      this.data=this.resData.data;
      console.log(this.data);
    })

   })

  }

  ngOnInit() {

  	this.id=localStorage.getItem('doctorid');
  	this.dser.request(this.id)
  	.subscribe(res=>{
  		this.resData=res;
  		this.data=this.resData.data;
      console.log(this.data);
  	})
  }

}
