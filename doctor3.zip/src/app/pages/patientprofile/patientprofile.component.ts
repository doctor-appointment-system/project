import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';
import {Router} from '@angular/router';


@Component({
  selector: 'app-patientprofile',
  templateUrl: './patientprofile.component.html',
  styleUrls: ['./patientprofile.component.css']
})
export class PatientprofileComponent implements OnInit {
eid;
resData;
data;

  constructor(private lser:DoctorserviceService) { }

  ngOnInit() {

this.eid=localStorage.getItem('patientid');
        this.lser.patientprofile(this.eid)
        .subscribe(res=>{
               this.resData=res;
               this.data=this.resData.data;
        })

  }

}
