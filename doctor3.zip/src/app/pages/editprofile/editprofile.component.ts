import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators} from '@angular/forms';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';
import {Router} from '@angular/router';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-editprofile',
  templateUrl: './editprofile.component.html',
  styleUrls: ['./editprofile.component.css']
})
export class EditprofileComponent implements OnInit {

myForm:FormGroup;
did;
e1id;
resData;

myImage;
user;
url;

defaultProfileimg;
  constructor(private fb:FormBuilder ,private lser:DoctorserviceService, private router:Router,private ar:ActivatedRoute) { }

editprofile(){
	let formData=this.myForm.getRawValue();
	this.e1id=localStorage.getItem('doctorid');

	this.lser.edit(formData,this.e1id)
	.subscribe(res=>{
		this.resData=res;
		console.log(this.resData);
		this.router.navigate(['/profile']);
	})
}


// fileUpload(event)
//   {
//     if(event.target.files.length>0)
//      {
//        this.myImage=event.target.files[0];
//        console.log(this.myImage);
//      }

//      this.user=localStorage.getItem('doctorid');
//     this.lser.upload1({'Image':this.myImage})
//     .subscribe(res=>{
//       console.log(res);
//     })

    
//   }

detectFiles(event){


  let files=event.target.files;
  
  if (files){
    for (let file of files){
      let reader=new FileReader();
      reader.onload = (e:any)=>{
        this.url=e.target.result;
        this.defaultProfileimg=this.url;
this.user=localStorage.getItem('doctorid');
         let data={
          user:this.user,
          img:this.url
        }

        this.lser.upload1(data)
        .subscribe(res=>{
           this.router.navigate(['/profile']);
        })
}
      
      reader.readAsDataURL(file);
    }
  }

}



  ngOnInit() {
  	this.validate();
  	this.e1id=localStorage.getItem('doctorid');

  	 this.ar.params.subscribe(par=>
      {
        this.did=par.eid;
        this.lser.fetchcatById(this.did)
        .subscribe(res=>
          {
         this.resData=res;
         this.myForm.patchValue(this.resData.cdata[0])
          })
      })
  }

   validate()
  {
    this.myForm=this.fb.group(
      {
        'name':['',Validators.required],
        'idnumber':['',Validators.required],
        'education':['',Validators.required],
        'mobile':['',Validators.required],
        'spec':['',Validators.required],
        'stime':['',Validators.required],
        'etime':['',Validators.required]
      }
    )
  }

}
