import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';
import {Router} from '@angular/router';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
eid;
resData;
data;
  constructor(private lser:DoctorserviceService) { }

  ngOnInit() {

  	this.eid=localStorage.getItem('doctorid');
        this.lser.profile(this.eid)
        .subscribe(res=>{
               this.resData=res;
               this.data=this.resData.data;
        })

  }

}
