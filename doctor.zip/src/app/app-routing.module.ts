import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';



import { HomeComponent } from './pages/home/home.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { AppointmentrequestComponent } from './pages/appointmentrequest/appointmentrequest.component';
import { EditprofileComponent } from './pages/editprofile/editprofile.component';
import { MainhomeComponent } from './pages/mainhome/mainhome.component';
import { RegisterComponent } from './pages/register/register.component';
import { SigninComponent } from './pages/signin/signin.component';
import { SignupComponent } from './pages/signup/signup.component';
import { DoctorloginComponent } from './pages/doctorlogin/doctorlogin.component';

const routes: Routes = [
{path:'profile',component:ProfileComponent},
{path:'dashboard',component:DashboardComponent},
{path:'appointmentrequest',component:AppointmentrequestComponent},
{path:'editprofile',component:EditprofileComponent},
{path:'',component:MainhomeComponent},
{path:'register',component:RegisterComponent},
{path:'signin',component:SigninComponent},
{path:'signup',component:SignupComponent},
{path:'doctorlogin',component:DoctorloginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
