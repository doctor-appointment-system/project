import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators} from '@angular/forms';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-doctorlogin',
  templateUrl: './doctorlogin.component.html',
  styleUrls: ['./doctorlogin.component.css']
})
export class DoctorloginComponent implements OnInit {

resData;
doctorid;
ok;
myForm:FormGroup;
  constructor(private fb:FormBuilder ,private lser:DoctorserviceService, private router:Router) { }

  doctorlogin(){
  	let formData=this.myForm.getRawValue();
  	this.lser.doctorLogin(formData)
  	.subscribe(res=>{
  		this.resData=res;
  		if (this.resData.err==0){
  			localStorage.setItem('doctorid',this.resData.user[0].username);
  			localStorage.setItem('dname',this.resData.user[0].name);
        this.router.navigate(['/dashboard']);
  		}
  	})
    if (this.doctorid!=undefined)
      this.ok="abc";
  }

  ngOnInit() {
  	this.validate();
  }


   validate()
  {
    this.myForm=this.fb.group(
      {
        'username':['',Validators.required],
        'password':['',Validators.required]
      }
    )
  }

}
