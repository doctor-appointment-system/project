const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const hospital = new Schema({
    name:String,
    address:String,
    mobile:Number,
    image:String
});
module.exports = mongoose.model('hospital',hospital);