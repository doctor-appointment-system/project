const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const avail = new Schema({
    date:String,
    doctorid:String,
    slotarr:Array
    
});
module.exports = mongoose.model('avail',avail);