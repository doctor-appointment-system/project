const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const adminsignup = new Schema({
    name:String,
    username:String,
     email:String,
    password:String
});
module.exports = mongoose.model('adminsignup',adminsignup);