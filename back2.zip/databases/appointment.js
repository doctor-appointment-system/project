const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const appointment = new Schema({
    date:String,
    doctorid:String,
    patientid:String,
    time:String
    
});
module.exports = mongoose.model('appointment',appointment);