const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const av = new Schema({
    date:String,
    doctorid:String,
    slotarr:Array['Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not','Not']
    
});
module.exports = mongoose.model('av',av);