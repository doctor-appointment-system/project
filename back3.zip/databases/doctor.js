const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const doctor = new Schema({
    name:String,
    username:String,
     email:String,
    password:String,
    id:String,
    education:String,
    meetingtime:String,
    mobile:Number,
    hospital:String,
    specilization:String,
    image:String
});
module.exports = mongoose.model('doctor',doctor);