const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const appointment = new Schema({
    date:String,
    doctorid:String,
    patientid:String,
    pname:String,
    dname:String,
    time:String,
    hospital:String,
    staus:String,
    accept:String
    
});
module.exports = mongoose.model('appointment',appointment);