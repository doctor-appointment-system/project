// All packages

const express=require('express');
const cors=require('cors');
const bodyParser=require('body-parser');
const sha1=require('sha1');
const mongoose=require('mongoose');
const nodemailer = require('nodemailer');


// const multer=require('multer');
// const path="./attach";
// let storage = multer.diskStorage({
//     destination: function (req, file, cb) {
//       cb(null,path)
//     },
//     filename: function (req, file, cb) {
//       cb(null, file.fieldname + '-' + Date.now()+ '.' + file.originalname.split('.')[file.originalname.split('.').length -1])
//     }
//   })
  
//   let upload = multer({ storage: storage }).single('Image');

//Creating a database 

mongoose.connect("mongodb://localhost/mimiproject",{
	useCreateIndex:true,
	useNewUrlParser:true
});

let adminSignup=require('./databases/adminsignup');
let doctorModel=require('./databases/doctor');
let patientModel=require('./databases/patient');
let hospitalModel=require('./databases/hospital');
let availModel=require('./databases/avail');
let appointmentModel=require('./databases/appointment');


let app=express();
app.use(cors());
app.use(bodyParser.json());

// app.use('/images',express.static('attach'));


  const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'karondiyan1999@gmail.com',
    pass: 'gulagula'
  }
});


//admin signup

app.post('/api/adminsignup',function(req,res){
  let name=req.body.name;
  let username=req.body.username;
  let email=req.body.email;
  let password=sha1(req.body.password);
  

   let ins=new adminSignup({'name':name,'email':email,'password':password,'username':username});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                   res.json({'err':0,'msg':'Account Created'});
                 }
           })


})


//admin login

app.post('/api/adminlogin',function(req,res){
	let username=req.body.username;
	let password=sha1(req.body.password);

	adminSignup.find({'username':username,'password':password},function(err,data){
		if (err){}
			else if (data.length==0){
				res.json({'err':1,'msg':'*username or password is not correct'});
			}
			else{
				res.json({'err':0,'msg':'Login Success','user':data});
			}
	})
})

app.post('/api/changepassword',function(req,res){

let username=req.body.username;
  let op=sha1(req.body.op);
  let np=sha1(req.body.np);

 

  adminSignup.find({'username':username},function(err,data){
    if (err){
    }
      else{
        let pass=data[0].password;
        if(op==pass){
adminSignup.update({'username':username},{$set:{'password':np}},function(err){
    if (err){
    }
      else{
        res.json({'err':0,'msg':'password change'});
      }
  })
}
else
{
  res.json({'err':1,'msg':'old password is not correct'});
}
      }
  })

  
})

app.post('/api/adddoctor',function(req,res){
  let name=req.body.dname;
  let email=req.body.email;
  let hospital=req.body.hospital;
   s=email.split("@");
   let username=s[0].toString();
    username=username+Math.floor(Math.random()*1000);
        let length=6;
      let password= '';
   let characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
   let charactersLength = characters.length;
   for (i = 0; i < length; i++ ) {
      password += characters.charAt(Math.floor(Math.random() * charactersLength));
   }
   let p=Math.floor(Math.random()*20)+password+Math.floor(Math.random()*20);
  password=sha1(p);


  let ins=new doctorModel({'name':name,'email':email,'password':password,'username':username,'hospital':hospital});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                            let mailOptions = {
                   from: 'karondiyan1999@gmail.com',
                   to: email,
                   subject: 'Added to DPAS 2019',
                   text: 'Hello!! I am sending a to notify you that you have been added to DPAS,\n your username is '+username +' and password is '+p+'\n'+'Thank you'
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
    res.json({'err':1,'msg':'Not send'});
  } else {
    console.log('Email sent: ' + info.response);
    res.json({'err':0,'msg':'Send Successfully'});
  }
});
                 }
           })


})


app.get('/api/showdoctor',function(req,res){

  doctorModel.find({},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'ddata':data});
      }
  })
})


//doctor login

app.post('/api/doctorlogin',function(req,res){
  let username=req.body.username;
  let password=sha1(req.body.password);
  
  doctorModel.find({'username':username,'password':password},function(err,data){
    if (err){
      console.log(err)
    }
      else if (data.length==0){

        res.json({'err':1,'msg':'*username or password is not correct'});
      }
      else{
        res.json({'err':0,'msg':'Login Success','user':data});
      }
  })
})


// patient signup

app.post('/api/patientsignup',function(req,res){
  let name=req.body.name;
  let email=req.body.email;
  let password=(req.body.password);
  let p=sha1(password)
  let mobile=req.body.mobile;

  console.log(name+" "+email+" ")


  

   let ins=new patientModel({'name':name,'email':email,'password':p,'mobile':mobile});
           ins.save(function(err)
           {
               if(err){
                console.log(err);
               }
               else
               {
                console.log("hii");
                res.json({'err':0,'msg':'saved Successfully'});
                   let mailOptions = {
                   from: 'karondiyan1999@gmail.com',
                   to: email,
                   subject: 'Registration In DPAS',
                   text: 'THANK YOU !! for register yourself as a patient in our project, \n you password is '+password
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
    res.json({'err':1,'msg':'Not send'});
  } else {
    console.log('Email sent: ' + info.response);
    res.json({'err':0,'msg':'Send Successfully'});
  }
});
                 }
           })


})


//patient login

app.post('/api/patientlogin',function(req,res){
  let username=req.body.username;
  let password=sha1(req.body.password);

  patientModel.find({'email':username,'password':password},function(err,data){
    if (err){}
      else if (data.length==0){
        res.json({'err':1,'msg':'*username or password is not correct'});
      }
      else{
        res.json({'err':0,'msg':'Login Success','user':data});
      }
  })
})









//add hospital in db

app.post('/api/addhospital',function(req,res){
  let name=req.body.hname;
  let address=req.body.address;
  let mobile=req.body.mobile;
   
  


  let ins=new hospitalModel({'name':name,'address':address,'mobile':mobile});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                       res.json({'err':0,'msg':' added Successfully'});     
                 }
           })


})




//show hospital

app.get('/api/showhospital',function(req,res){

  hospitalModel.find({},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'ddata':data});
      }
  })
})



//fetch doctors of selected hospitals 
app.get('/api/fetchdoctor/:hname',function(req,res){
   let hname=req.params.hname;
   if (hname=='Galasphere Hospital New Hathras')
    hname='Galasphere Hospital New Hathras ';
   console.log(hname);
  doctorModel.find({'hospital':hname},function(err,data){
    if (err){}
      else{
        console.log(data.length);
        res.json({'err':0,'ddata':data});
      }
  })
})

app.get('/api/fetchdid/:did',function(req,res){
   let did=req.params.did;
  doctorModel.find({'username':did},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'cdata':data});
      }
  })
})


//edit profile

app.post('/api/edit/:eid',function(req,res){
  let eid=req.params.eid;
  let name=req.body.name;
  let education=req.body.education;
  let mobile=req.body.mobile;
  let idnumber=req.body.idnumber;
  let stime=req.body.stime;
  let etime=req.body.etime;
  let spec=req.body.spec;

  let time=stime+'to'+etime;

  console.log(eid+" "+name+" "+education+" "+mobile+" "+idnumber+" "+stime+" "+etime+" "+spec);

  
                

                doctorModel.update({'username':eid},{$set:{'education':education,'mobile':mobile,'id':idnumber,'specilization':spec,'meetingtime':time}},function(err){
                  if (err){}
                    else{
                      console.log("profile changed");
                    }
                })
              
          
})

//profile

app.get('/api/profile/:eid',function(req,res){
  let eid=req.params.eid;

  doctorModel.find({'username':eid},function(err,data){
         if (err){}
          else{
            res.json({'err':0,'data':data});
          }
  })
})

//show avilability


app.post('/api/showavail/:id',function(req,res){
  let id=req.params.id;
  console.log(id);
      doctorModel.find({'_id':id},function(err,data){
        if (err){}
          else{
            var user=data[0].username;
            console.log(data[0].meetingtime);
            var m=data[0].meetingtime;
            var v=m.split("to");
            var h1=parseInt(v[0][0].toString()+v[0][1].toString());
            var m1=parseInt(v[0][3].toString()+v[0][4].toString());
            var h2=parseInt(v[1][0].toString()+v[1][1].toString());
            var m2=parseInt(v[1][3].toString()+v[1][4].toString());

            var starth=(h1-8)*2+1;
            var endh=(h2-8)*2;
            if (m1!=0)
              starth=starth+1;
            if (m2!=0)
              endh=endh+1;

        


var date=req.body.day+'-'+req.body.month+'-'+req.body.year;
         
   var slot=new Array();
   var a="Available";
   var b="Not Available";

   for (i=0;i<24;i++){
    if (i>=starth-1&&i<=endh-1)
      slot[i]="Available";
    else
      slot[i]="Not Available";
   }

   availModel.find({'date':date,'doctorid':user},function(err,data){
    if (err){}
      else{
        if (data.length==0){
          let ins=new availModel({'date':date,'doctorid':user,'slotarr':slot});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                       res.json({'err':0,'msg':' added Successfully'});     
                 }
           })
        }
        else{
          res.json({'err':0,'msg':'already present'});
        }
      }
   })
         
}
      })

})



//avail

app.post('/api/avail/:id',function(req,res){

  var id=req.params.id;
  console.log(id);

   doctorModel.find({'_id':id},function(err,data){
    if (err){}
      else{
var date=req.body.day+'-'+req.body.month+'-'+req.body.year;

var user=data[0].username;

    availModel.find({'date':date ,'doctorid':user},function(err,data){
      if (err){}
        else{
         res.json({'err':0,'data':data[0].slotarr});
        }
    })
      }
   })

 
   // availModel.find({},function(err,data){
   //  if (err){}
   //    else{
   //      res.json({'err':0,'data':data[0].slot});
   //    }
   // })

})


// book 

app.post('/api/book',function(req,res){
  var id=req.body.id;
  var index=req.body.index;
  console.log(index);
  var date=req.body.day+'-'+req.body.month+'-'+req.body.year;
  var pid=req.body.pid;
  var pname;

  patientModel.find({'email':pid},function(err,data){
    if (err){}
      else{
           pname=data[0].name;
      }
  })

  var time;
  if ((index-1)%2==0){
    let t1=8+(index-1)/2;
    time=t1+":00";
  }
  else{
    let t1=8+parseInt((index-1)/2);
    time=t1+":30";
  }

doctorModel.find({'_id':id},function(err,data){
  if (err){}
    else{
      var user=data[0].username;
      var name=data[0].name;
      var hospital=data[0].hospital;

      availModel.find({'doctorid':user,'date':date},function(err,data){
        if (err){}
          else{


            
           if (data[0].slotarr[index-1]=="Available"){
            data[0].slotarr[index-1]="Requested";
            var staus="Requested";
           
           availModel.update({'date':date,'doctorid':user},{$set:{'slotarr':data[0].slotarr}},function(err){
            if (err){}
              else{
                 
                 var accept="Accept";

             let ins=new appointmentModel({'date':date,'doctorid':id,'patientid':pid,'time':time,'pname':pname,'dname':name,'hospital':hospital,'staus':staus,'accept':accept});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                       res.json({'err':0,'msg':' added Successfully'});     
                 }
           })

              }
           })
            }
          }
          
      })
    }
})


})


//request

app.get('/api/request/:id',function(req,res){

  let id=req.params.id;
  console.log(id);

  doctorModel.find({'username':id},function(err,data){
    if (err){}
      else{
          var id1=data[0]._id;
         appointmentModel.find({'doctorid':id1},function(err,data){
    if (err){}
      else{
        
        res.json({'err':0,'data':data});
      }
  })
      }
  })

 
})


//accept request

app.post('/api/accept',function(req,res){
 var id=req.body.id;
 var user=req.body.user;
 var doctorid;
 var patientid;
 var time;
 var date;

  appointmentModel.find({'_id':id},function(err,data){
    if (err){}
      else{
         doctorid=data[0].doctorid;
         patientid=data[0].patientid;
         date=data[0].date;
         time=data[0].time;
      
  

  console.log(time);

  
 var h1=2*(parseInt(time[0]+time[1])-8);

 if (time[3]+time[4]=="00")
  h1=h1+1;
else
  h1=h1+2;

console.log(h1);




 

  availModel.find({'doctorid':user,'date':date},function(err,data){
       if (err){}
        else{

          
          if (data[0].slotarr[h1-1]=="Requested"||data[0].slotarr[h1-1]=="Booked"){
            data[0].slotarr[h1-1]="Booked";

 availModel.update({'date':date,'doctorid':user},{$set:{'slotarr':data[0].slotarr}},function(err){
            if (err){}
              else{
                   var staus="Booked";
                   var accept="Accepted";
                appointmentModel.update({'time':time,'date':date,'patientid':patientid,'doctorid':doctorid}
                  ,{$set:{'staus':staus,'accept':accept}},function(err){
                    if (err){}
                      else{
                        res.json({'err':0,'msg':'accepted'});
                      }
                  })
              }

          })
}
        }
  })
}
})

})


//delete

app.post('/api/deleted',function(req,res){

  var id=req.body.id;
  var user=req.body.user;

  var doctorid;
 var patientid;
 var time;
 var date;

  appointmentModel.find({'_id':id},function(err,data){
    if (err){}
      else{
         doctorid=data[0].doctorid;
         patientid=data[0].patientid;
         date=data[0].date;
         time=data[0].time;
      
  

  console.log(time);

  
 var h1=2*(parseInt(time[0]+time[1])-8);

 if (time[3]+time[4]=="00")
  h1=h1+1;
else
  h1=h1+2;

console.log(h1);




 

  availModel.find({'doctorid':user,'date':date},function(err,data){
       if (err){}
        else{

          
          if (data[0].slotarr[h1-1]=="Requested"||data[0].slotarr[h1-1]=="Booked"){
            data[0].slotarr[h1-1]="Available";

 availModel.update({'date':date,'doctorid':user},{$set:{'slotarr':data[0].slotarr}},function(err){
            if (err){}
              else{
                   
                appointmentModel.remove({'time':time,'date':date,'patientid':patientid,'doctorid':doctorid},function(err){
                    if (err){}
                      else{
                        res.json({'err':0,'msg':'deleted'});
                      }
                  })
              }

          })
}
        }
  })
}
})



})


//uplaod image

app.post('/api/upload',function(req,res){

        var user=req.body.user;
        var image=req.body.img;
        

        doctorModel.update({'username':user},{$set:{'image':image}},function(err){
          if (err){}
            else{
              res.json({'err':0,'msg':'uplaod Successfully'});
            }
        })
       

})

//patient profile

app.get('/api/patientprofile/:eid',function(req,res){
  let eid=req.params.eid;

  patientModel.find({'email':eid},function(err,data){
         if (err){}
          else{
            res.json({'err':0,'data':data});
          }
  })
})


app.get('/api/fetchpatient/:did',function(req,res){
   let did=req.params.did;
  patientModel.find({'email':did},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'cdata':data});
      }
  })
})


app.post('/api/patientedit/:eid',function(req,res){
  let eid=req.params.eid;
  let name=req.body.name;
  let age=req.body.age;
  let mobile=req.body.mobile;
  let address=req.body.address;

  console.log(age);

  

  
                

                patientModel.update({'email':eid},{$set:{'mobile':mobile,'address':address,'Age':age}},function(err){
                  if (err){}
                    else{
                      res.json({'err':0,'msg':'profile changed'});
                    }
                })
              
          
})


app.post('/api/upload1',function(req,res){

        var user=req.body.user;
        var image=req.body.img;
        

        patientModel.update({'email':user},{$set:{'image':image}},function(err){
          if (err){}
            else{
              res.json({'err':0,'msg':'uplaod Successfully'});
            }
        })
       

})

//my appointment

app.get('/api/myappointment/:id',function(req,res){
  var id=req.params.id;
  console.log(id);

  appointmentModel.find({'patientid':id},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'data':data});
      }
  })
})


app.post('/api/deleted1',function(req,res){

  var id=req.body.id;
  var user=req.body.user;

  var doctorid;
 var patientid;
 var time;
 var date;

  appointmentModel.find({'_id':id},function(err,data){
    if (err){}
      else{
         doctorid=data[0].doctorid;
         patientid=data[0].patientid;
         date=data[0].date;
         time=data[0].time;
      
  

  console.log(time);

  
 var h1=2*(parseInt(time[0]+time[1])-8);

 if (time[3]+time[4]=="00")
  h1=h1+1;
else
  h1=h1+2;

console.log(h1);

 doctorModel.find({'_id':doctorid},function(err,data){
  if (err){}
    else{
      var user1=data[0].username;
      console.log(user1);
 


 

  availModel.find({'doctorid':user1,'date':date},function(err,data){
       if (err){}
        else{

          
          if (data[0].slotarr[h1-1]=="Requested"||data[0].slotarr[h1-1]=="Booked"){
            data[0].slotarr[h1-1]="Available";

 availModel.update({'date':date,'doctorid':user1},{$set:{'slotarr':data[0].slotarr}},function(err){
            if (err){}
              else{
                   
                appointmentModel.remove({'time':time,'date':date,'patientid':patientid,'doctorid':doctorid},function(err){
                    if (err){}
                      else{
                        res.json({'err':0,'msg':'deleted'});
                      }
                  })
              }

          })
}
        }
  })
     }
 })
}
})



})



app.listen(8080,function(){
	console.log("Works on 8080");
})

