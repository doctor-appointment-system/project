import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';



import { HomeComponent } from './pages/home/home.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { AppointmentrequestComponent } from './pages/appointmentrequest/appointmentrequest.component';
import { EditprofileComponent } from './pages/editprofile/editprofile.component';
import { MainhomeComponent } from './pages/mainhome/mainhome.component';
import { RegisterComponent } from './pages/register/register.component';
import { SigninComponent } from './pages/signin/signin.component';
import { SignupComponent } from './pages/signup/signup.component';
import { DoctorloginComponent } from './pages/doctorlogin/doctorlogin.component';
import { BookappointmentComponent } from './pages/bookappointment/bookappointment.component';
import { SelectdoctorComponent } from './pages/selectdoctor/selectdoctor.component';
import { PappointmentComponent } from './pages/pappointment/pappointment.component';

const routes: Routes = [
{path:'profile',component:ProfileComponent},
{path:'dashboard',component:DashboardComponent},
{path:'appointmentrequest',component:AppointmentrequestComponent},
{path:'editprofile/:eid',component:EditprofileComponent},
{path:'',component:MainhomeComponent},
{path:'register',component:RegisterComponent},
{path:'signin',component:SigninComponent},
{path:'signup',component:SignupComponent},
{path:'doctorlogin',component:DoctorloginComponent},
{path:'bookappointment',component:BookappointmentComponent},
{path:'selectdoctor/:hname',component:SelectdoctorComponent},
{path:'pappointment/:id',component:PappointmentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
