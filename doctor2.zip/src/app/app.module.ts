import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './pages/home/home.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { AppointmentrequestComponent } from './pages/appointmentrequest/appointmentrequest.component';
import { EditprofileComponent } from './pages/editprofile/editprofile.component';
import { MainhomeComponent } from './pages/mainhome/mainhome.component';
import { RegisterComponent } from './pages/register/register.component';
import { SigninComponent } from './pages/signin/signin.component';
import { SignupComponent } from './pages/signup/signup.component';
import { DoctorloginComponent } from './pages/doctorlogin/doctorlogin.component';
import { BookappointmentComponent } from './pages/bookappointment/bookappointment.component';
import { SelectdoctorComponent } from './pages/selectdoctor/selectdoctor.component';
import { PappointmentComponent } from './pages/pappointment/pappointment.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    DashboardComponent,
    ProfileComponent,
    AppointmentrequestComponent,
    EditprofileComponent,
    MainhomeComponent,
    RegisterComponent,
    SigninComponent,
    SignupComponent,
    DoctorloginComponent,
    BookappointmentComponent,
    SelectdoctorComponent,
    PappointmentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
