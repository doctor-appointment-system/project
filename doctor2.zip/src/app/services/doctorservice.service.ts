import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DoctorserviceService {
 
 url="http://localhost:8080/api/";
  
  constructor(private http:HttpClient) { }


doctorLogin(data){
	return this.http.post(this.url+'doctorlogin',data);
}

patientsignup(data){
	return this.http.post(this.url+'patientsignup',data);
}

patientLogin(data){
	return this.http.post(this.url+'patientlogin',data);
}

showHospital(){
    return this.http.get(this.url+'showhospital');
  }

 fetchDoctor(hname)
 {
 	return this.http.get(this.url+'fetchdoctor/'+hname);
 }

fetchcatById(did){
    return this.http.get(this.url+'fetchdid/'+did);
}

edit(data,eid){
	return this.http.post(this.url+'edit/'+eid,data);
}

profile(eid){
	return this.http.get(this.url+'profile/'+eid);
}

showavail(id,data){
	return this.http.post(this.url+'showavail/'+id,data);
}


avail(id,data){
	return this.http.post(this.url+'avail/'+id,data);
}


book(data){
	return this.http.post(this.url+'book',data);
}

request(id){
	return this.http.get(this.url+'request/'+id);
}

}
