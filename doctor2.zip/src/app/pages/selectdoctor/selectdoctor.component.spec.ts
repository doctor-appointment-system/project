import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectdoctorComponent } from './selectdoctor.component';

describe('SelectdoctorComponent', () => {
  let component: SelectdoctorComponent;
  let fixture: ComponentFixture<SelectdoctorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectdoctorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectdoctorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
