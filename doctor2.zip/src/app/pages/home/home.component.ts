import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
doctorid;
doctor;
patient;
dname;
patientid;
pname;
  constructor(private router:Router) { }

  signOut()
   {
     localStorage.removeItem('doctorid');
     localStorage.removeItem('dname');
      this.router.navigate(['/'])
      document.location.reload(true);
   }

    signOut1()
   {
     localStorage.removeItem('patientid');
     localStorage.removeItem('pname');
      this.router.navigate(['/'])
      document.location.reload(true);
   }

  ngOnInit() {
  	this.doctorid=localStorage.getItem('doctorid');
  	this.dname=localStorage.getItem('dname');
  	if (this.doctorid!=undefined){
  		this.doctor="abc"
  		this.patient=undefined;
  	}

    this.patientid=localStorage.getItem('patientid');
    this.pname=localStorage.getItem('pname');

    if (this.patientid!=undefined){
      this.doctor=undefined;
      this.patient="abc";
    }
  }

}
