import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators} from '@angular/forms';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';
import {Router} from '@angular/router';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-editprofile',
  templateUrl: './editprofile.component.html',
  styleUrls: ['./editprofile.component.css']
})
export class EditprofileComponent implements OnInit {

myForm:FormGroup;
did;
e1id;
resData;

  constructor(private fb:FormBuilder ,private lser:DoctorserviceService, private router:Router,private ar:ActivatedRoute) { }

editprofile(){
	let formData=this.myForm.getRawValue();
	this.e1id=localStorage.getItem('doctorid');

	this.lser.edit(formData,this.e1id)
	.subscribe(res=>{
		this.resData=res;
		console.log(this.resData);
		this.router.navigate(['/profile']);
	})
}

  ngOnInit() {
  	this.validate();
  	this.e1id=localStorage.getItem('doctorid');

  	 this.ar.params.subscribe(par=>
      {
        this.did=par.eid;
        this.lser.fetchcatById(this.did)
        .subscribe(res=>
          {
         this.resData=res;
         this.myForm.patchValue(this.resData.cdata[0])
          })
      })
  }

   validate()
  {
    this.myForm=this.fb.group(
      {
        'name':['',Validators.required],
        'idnumber':['',Validators.required],
        'education':['',Validators.required],
        'mobile':['',Validators.required],
        'spec':['',Validators.required],
        'stime':['',Validators.required],
        'etime':['',Validators.required]
      }
    )
  }

}
