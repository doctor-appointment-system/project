import { Component, OnInit } from '@angular/core';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-pappointment',
  templateUrl: './pappointment.component.html',
  styleUrls: ['./pappointment.component.css']
})
export class PappointmentComponent implements OnInit {
  constructor(private dser:DoctorserviceService,private ar:ActivatedRoute) { }
    
resData;
data;
id;
p;
color;
index;
day;
month;
year;
userid;

currentbutton1:string;

inlinecolor1:string;
inlinecolor2:string;
inlinecolor3:string;
inlinecolor4:string;
inlinecolor5:string;
inlinecolor6:string;
inlinecolor7:string;
inlinecolor8:string;
inlinecolor9:string;
inlinecolor10:string;
inlinecolor11:string;
inlinecolor12:string;
inlinecolor13:string;
inlinecolor14:string;
inlinecolor15:string;
inlinecolor16:string;
inlinecolor17:string;
inlinecolor18:string;
inlinecolor19:string;
inlinecolor20:string;
inlinecolor21:string;
inlinecolor22:string;
inlinecolor23:string;
inlinecolor24:string;

disable1:boolean;
disable2:string="!";
disable3:string="1";disable4:string="1";disable5:string="1";disable6:string="1";disable7:string="1";disable8:string="1";
disable9:string="1";disable10:string="1";disable11:string="1";disable12:string="1";disable13:string="1";disable14:string="1";
disable15:string="1";disable16:string="1";disable17:string="1";disable18:string="1";disable19:string="1";disable20:string="1";
disable21:string="1";disable22:string="1";disable23:string="1";disable24:string="1";

non(){
	return true;
}


book(event){
     console.log(event.target.id);

     this.day=localStorage.getItem('day');
	this.month=localStorage.getItem('month');
	this.year=localStorage.getItem('year');
	this.userid=localStorage.getItem('patientid');
  this.ar.params.subscribe(par=>{
      this.dser.book({'id':par.id,'index':event.target.id,'day':this.day,'month':this.month,'year':this.year,'pid':this.userid}).
      subscribe(res=>{
      	this.dser.avail(this.id,{'day':this.day,'month':this.month,'year':this.year})
   .subscribe(res=>{
   	this.resData=res;
   	this.data=this.resData.data;
   	console.log(this.data[0]);

   	 if (this.data[0]=="Available"){
	this.inlinecolor1="green";
}
else if (this.data[0]=="Booked"){
	this.inlinecolor1="yellow";
	this.disable1=true;
}
else{
	this.inlinecolor1="red";
	this.disable1=true;
}
	 if (this.data[1]=="Available"){
	this.inlinecolor2="green";
}
else if (this.data[1]=="Booked"){
	this.inlinecolor2="yellow";
	this.disable2="0.5";
}
else{
	this.inlinecolor2="red";
	this.disable2="0.5";
}

	 if (this.data[2]=="Available"){
	this.inlinecolor3="green";
}

else if (this.data[2]=="Booked"){
	this.inlinecolor3="yellow";
	this.disable3="0.5";
}
else{
	this.inlinecolor3="red";
	this.disable3="0.5";
}
	 if (this.data[3]=="Available"){
	this.inlinecolor4="green";
}

else if (this.data[3]=="Booked"){
	this.inlinecolor4="yellow";
	this.disable4="0.5";
}
else{
	this.inlinecolor4="red";
	this.disable4="0.5";
}
	 if (this.data[4]=="Available"){
	this.inlinecolor5="green";
}
else if (this.data[4]=="Booked"){
	this.inlinecolor5="yellow";
	this.disable5="0.5";
}
else{
	this.inlinecolor5="red";
	this.disable5="0.5";
}
	 if (this.data[5]=="Available"){
	this.inlinecolor6="green";
}

else if (this.data[5]=="Booked"){
	this.inlinecolor6="yellow";
	this.disable6="0.5";

}
else{
	this.inlinecolor6="red";
	this.disable6="0.5";
}
	 if (this.data[6]=="Available"){
	this.inlinecolor7="green";
}
else if (this.data[6]=="Booked"){
	this.inlinecolor7="yellow";
	this.disable7="0.5";
}
else{
	this.inlinecolor7="red";
	this.disable7="0.5";
}
	 if (this.data[7]=="Available"){
	this.inlinecolor8="green";
}

else if (this.data[7]=="Booked"){
	this.inlinecolor8="yellow";
	this.disable8="0.5";
}
else{
	this.inlinecolor8="red";
	this.disable8="0.5";
}
	 if (this.data[8]=="Available"){
	this.inlinecolor9="green";
}

else if (this.data[8]=="Booked"){
	this.inlinecolor9="yellow";
	this.disable9="0.5";
}
else{
	this.inlinecolor9="red";
	this.disable9="0.5";
}
	 if (this.data[9]=="Available"){
	this.inlinecolor10="green";
}

else if (this.data[9]=="Booked"){
	this.inlinecolor10="yellow";
	this.disable10="0.5";
}
else{
	this.inlinecolor10="red";
	this.disable10="0.5";
}
	 if (this.data[10]=="Available"){
	this.inlinecolor11="green";
}

else if (this.data[10]=="Booked"){
	this.inlinecolor11="yellow";
	this.disable11="0.5";
}
else{
	this.inlinecolor11="red";
	this.disable11="0.5";
}
	 if (this.data[11]=="Available"){
	this.inlinecolor12="green";
}

else if (this.data[11]=="Booked"){
	this.inlinecolor12="yellow";
	this.disable12="0.5";
}
else{
	this.inlinecolor12="red";
	this.disable12="0.5";
}
	 if (this.data[12]=="Available"){
	this.inlinecolor13="green";
}
else if (this.data[12]=="Booked"){
	this.inlinecolor13="yellow";
	this.disable13="0.5";
}
else{
	this.inlinecolor13="red";
	this.disable13="0.5";
}
	 if (this.data[13]=="Available"){
	this.inlinecolor14="green";
}
else if (this.data[13]=="Booked"){
	this.inlinecolor14="yellow";
	this.disable14="0.5";
}
else{
	this.inlinecolor14="red";
	this.disable14="0.5";
}
	 if (this.data[14]=="Available"){
	this.inlinecolor15="green";
}
else if (this.data[14]=="Booked"){
	this.inlinecolor15="yellow";
	this.disable15="0.5";
}
else{
	this.inlinecolor15="red";
	this.disable15="0.5";
}
	 if (this.data[15]=="Available"){
	this.inlinecolor16="green";
}
else if (this.data[15]=="Booked"){
	this.inlinecolor16="yellow";
	this.disable16="0.5";
}
else{
	this.inlinecolor16="red";
	this.disable16="0.5";
}
	 if (this.data[16]=="Available"){
	this.inlinecolor17="green";
}
else if (this.data[16]=="Booked"){
	this.inlinecolor17="yellow";
	this.disable17="0.5";
}
else{
	this.inlinecolor17="red";
	this.disable17="0.5";
}
	 if (this.data[17]=="Available"){
	this.inlinecolor18="green";
}
else if (this.data[17]=="Booked"){
	this.inlinecolor18="yellow";
	this.disable18="0.5";
}
else{
	this.inlinecolor18="red";
	this.disable18="0.5";
}
	 if (this.data[18]=="Available"){
	this.inlinecolor19="green";
}

else if (this.data[18]=="Booked"){
	this.inlinecolor19="yellow";
	this.disable19="0.5";
}
else{
	this.inlinecolor19="red";
	this.disable19="0.5";
}
	 if (this.data[19]=="Available"){
	this.inlinecolor20="green";
}
else if (this.data[19]=="Booked"){
	this.inlinecolor20="yellow";
		this.disable20="0.5";
}
else{
	this.inlinecolor20="red";
	this.disable20="0.5";
}
	 if (this.data[20]=="Available"){
	this.inlinecolor21="green";
}
else if (this.data[20]=="Booked"){
	this.inlinecolor21="yellow";
	this.disable21="0.5";
}
else{
	this.inlinecolor21="red";
	this.disable21="0.5";
}
	 if (this.data[21]=="Available"){
	this.inlinecolor22="green";
}
else if (this.data[21]=="Booked"){
	this.inlinecolor22="yellow";
	this.disable22="0.5";
}
else{
	this.inlinecolor22="red";
	this.disable22="0.5";
}
	 if (this.data[22]=="Available"){
	this.inlinecolor23="green";
}
else if (this.data[22]=="Booked"){
	this.inlinecolor23="yellow";
	this.disable23="0.5";
}
else{
	this.inlinecolor23="red";
	this.disable23="0.5";
}
	 if (this.data[23]=="Available"){
	this.inlinecolor24="green";
}
else if (this.data[23]=="Booked"){
	this.inlinecolor24="yellow";
	this.disable24="0.5";
}
else{
	this.inlinecolor24="red";
	this.disable24="0.5";
}
     })

      })
  	})

   }


  ngOnInit() {

  	this.day=localStorage.getItem('day');
	this.month=localStorage.getItem('month');
	this.year=localStorage.getItem('year');
this.ar.params.subscribe(par=>{
	this.id=par.id;
	
	console.log(par.id);
      this.dser.showavail(par.id,{'day':this.day,'month':this.month,'year':this.year}).subscribe(res=>{
       console.log(res);
      })
  	})


   this.dser.avail(this.id,{'day':this.day,'month':this.month,'year':this.year})
   .subscribe(res=>{
   	this.resData=res;
   	this.data=this.resData.data;
   	console.log(this.data[0]);

   	if (this.data[0]=="Available"){
	this.inlinecolor1="green";
}
else if (this.data[0]=="Booked"){
	this.inlinecolor1="yellow";
	this.disable1=true;
}
else{
	this.inlinecolor1="red";
	this.disable1=true;
}
	 if (this.data[1]=="Available"){
	this.inlinecolor2="green";
}
else if (this.data[1]=="Booked"){
	this.inlinecolor2="yellow";
	this.disable2="0.5";
}
else{
	this.inlinecolor2="red";
	this.disable2="0.5";
}

	 if (this.data[2]=="Available"){
	this.inlinecolor3="green";
}

else if (this.data[2]=="Booked"){
	this.inlinecolor3="yellow";
	this.disable3="0.5";
}
else{
	this.inlinecolor3="red";
	this.disable3="0.5";
}
	 if (this.data[3]=="Available"){
	this.inlinecolor4="green";
}

else if (this.data[3]=="Booked"){
	this.inlinecolor4="yellow";
	this.disable4="0.5";
}
else{
	this.inlinecolor4="red";
	this.disable4="0.5";
}
	 if (this.data[4]=="Available"){
	this.inlinecolor5="green";
}
else if (this.data[4]=="Booked"){
	this.inlinecolor5="yellow";
	this.disable5="0.5";
}
else{
	this.inlinecolor5="red";
	this.disable5="0.5";
}
	 if (this.data[5]=="Available"){
	this.inlinecolor6="green";
}

else if (this.data[5]=="Booked"){
	this.inlinecolor6="yellow";
	this.disable6="0.5";

}
else{
	this.inlinecolor6="red";
	this.disable6="0.5";
}
	 if (this.data[6]=="Available"){
	this.inlinecolor7="green";
}
else if (this.data[6]=="Booked"){
	this.inlinecolor7="yellow";
	this.disable7="0.5";
}
else{
	this.inlinecolor7="red";
	this.disable7="0.5";
}
	 if (this.data[7]=="Available"){
	this.inlinecolor8="green";
}

else if (this.data[7]=="Booked"){
	this.inlinecolor8="yellow";
	this.disable8="0.5";
}
else{
	this.inlinecolor8="red";
	this.disable8="0.5";
}
	 if (this.data[8]=="Available"){
	this.inlinecolor9="green";
}

else if (this.data[8]=="Booked"){
	this.inlinecolor9="yellow";
	this.disable9="0.5";
}
else{
	this.inlinecolor9="red";
	this.disable9="0.5";
}
	 if (this.data[9]=="Available"){
	this.inlinecolor10="green";
}

else if (this.data[9]=="Booked"){
	this.inlinecolor10="yellow";
	this.disable10="0.5";
}
else{
	this.inlinecolor10="red";
	this.disable10="0.5";
}
	 if (this.data[10]=="Available"){
	this.inlinecolor11="green";
}

else if (this.data[10]=="Booked"){
	this.inlinecolor11="yellow";
	this.disable11="0.5";
}
else{
	this.inlinecolor11="red";
	this.disable11="0.5";
}
	 if (this.data[11]=="Available"){
	this.inlinecolor12="green";
}

else if (this.data[11]=="Booked"){
	this.inlinecolor12="yellow";
	this.disable12="0.5";
}
else{
	this.inlinecolor12="red";
	this.disable12="0.5";
}
	 if (this.data[12]=="Available"){
	this.inlinecolor13="green";
}
else if (this.data[12]=="Booked"){
	this.inlinecolor13="yellow";
	this.disable13="0.5";
}
else{
	this.inlinecolor13="red";
	this.disable13="0.5";
}
	 if (this.data[13]=="Available"){
	this.inlinecolor14="green";
}
else if (this.data[13]=="Booked"){
	this.inlinecolor14="yellow";
	this.disable14="0.5";
}
else{
	this.inlinecolor14="red";
	this.disable14="0.5";
}
	 if (this.data[14]=="Available"){
	this.inlinecolor15="green";
}
else if (this.data[14]=="Booked"){
	this.inlinecolor15="yellow";
	this.disable15="0.5";
}
else{
	this.inlinecolor15="red";
	this.disable15="0.5";
}
	 if (this.data[15]=="Available"){
	this.inlinecolor16="green";
}
else if (this.data[15]=="Booked"){
	this.inlinecolor16="yellow";
	this.disable16="0.5";
}
else{
	this.inlinecolor16="red";
	this.disable16="0.5";
}
	 if (this.data[16]=="Available"){
	this.inlinecolor17="green";
}
else if (this.data[16]=="Booked"){
	this.inlinecolor17="yellow";
	this.disable17="0.5";
}
else{
	this.inlinecolor17="red";
	this.disable17="0.5";
}
	 if (this.data[17]=="Available"){
	this.inlinecolor18="green";
}
else if (this.data[17]=="Booked"){
	this.inlinecolor18="yellow";
	this.disable18="0.5";
}
else{
	this.inlinecolor18="red";
	this.disable18="0.5";
}
	 if (this.data[18]=="Available"){
	this.inlinecolor19="green";
}

else if (this.data[18]=="Booked"){
	this.inlinecolor19="yellow";
	this.disable19="0.5";
}
else{
	this.inlinecolor19="red";
	this.disable19="0.5";
}
	 if (this.data[19]=="Available"){
	this.inlinecolor20="green";
}
else if (this.data[19]=="Booked"){
	this.inlinecolor20="yellow";
		this.disable20="0.5";
}
else{
	this.inlinecolor20="red";
	this.disable20="0.5";
}
	 if (this.data[20]=="Available"){
	this.inlinecolor21="green";
}
else if (this.data[20]=="Booked"){
	this.inlinecolor21="yellow";
	this.disable21="0.5";
}
else{
	this.inlinecolor21="red";
	this.disable21="0.5";
}
	 if (this.data[21]=="Available"){
	this.inlinecolor22="green";
}
else if (this.data[21]=="Booked"){
	this.inlinecolor22="yellow";
	this.disable22="0.5";
}
else{
	this.inlinecolor22="red";
	this.disable22="0.5";
}
	 if (this.data[22]=="Available"){
	this.inlinecolor23="green";
}
else if (this.data[22]=="Booked"){
	this.inlinecolor23="yellow";
	this.disable23="0.5";
}
else{
	this.inlinecolor23="red";
	this.disable23="0.5";
}
	 if (this.data[23]=="Available"){
	this.inlinecolor24="green";
}
else if (this.data[23]=="Booked"){
	this.inlinecolor24="yellow";
	this.disable24="0.5";
}
else{
	this.inlinecolor24="red";
	this.disable24="0.5";
}
     })
 
 

}


 
  

}
