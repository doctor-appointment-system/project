import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators} from '@angular/forms';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';
import {Router} from '@angular/router';


@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
	
myForm:FormGroup;	
resData;
patientid;
pname;
  constructor(private fb:FormBuilder ,private lser:DoctorserviceService, private router:Router) { }

  patientlogin(){
  	let formData=this.myForm.getRawValue();
  	this.lser.patientLogin(formData)
  	.subscribe(res=>{
  		this.resData=res;
  		console.log(this.resData);
  		if (this.resData.err==0){
  			localStorage.setItem('patientid',this.resData.user[0].email);
  			localStorage.setItem('pname',this.resData.user[0].name);
        this.router.navigate(['/']);
        document.location.reload(true);
  		}

  	})
  }
   

  ngOnInit() {
  	this.validate();
  }


 validate()
  {
    this.myForm=this.fb.group(
      {
        'username':['',Validators.required],
        'password':['',Validators.required]
      }
    )
  }

  
}
