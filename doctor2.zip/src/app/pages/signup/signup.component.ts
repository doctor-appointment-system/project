import { Component, OnInit } from '@angular/core';

import { FormGroup,FormBuilder,Validators} from '@angular/forms';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
myForm:FormGroup;
	
resData;
  constructor(private fb:FormBuilder ,private lser:DoctorserviceService, private router:Router) { }

patientSignup(){

   	let formData=this.myForm.getRawValue();
  	this.lser.patientsignup(formData)
  	.subscribe(res=>{
  		this.resData=res;
  		console.log(this.resData);
          this.router.navigate(['/signin']);
  	})

   }

  ngOnInit() {
  	this.validate();
  }


  validate()
  {
    this.myForm=this.fb.group(
      {
        'name':['',Validators.required],
        'password':['',Validators.required],
        'email':['',Validators.required],
        'mobile':['',Validators.required]
      }
    )
  }

}
