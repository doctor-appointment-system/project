import { Component, OnInit } from '@angular/core';
import { DoctorserviceService } from 'src/app/services/doctorservice.service';

@Component({
  selector: 'app-appointmentrequest',
  templateUrl: './appointmentrequest.component.html',
  styleUrls: ['./appointmentrequest.component.css']
})
export class AppointmentrequestComponent implements OnInit {

  constructor(private dser:DoctorserviceService) { }

  ngOnInit() {

  	this.id=localStorage.getItem('doctorid');
  	this.dser.request(this.id)
  	.subscribe(res=>{
  		
  	})
  }

}
