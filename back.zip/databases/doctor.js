const  mongoose = require('mongoose');
const Schema = mongoose.Schema;
const doctor = new Schema({
    name:String,
    username:String,
     email:String,
    password:String,
    id:String,
    address:String,
    education:String,
    meetingtime:String,
    mobile:Number
});
module.exports = mongoose.model('doctor',doctor);