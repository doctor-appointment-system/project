import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators} from '@angular/forms';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';
import {Router} from '@angular/router';

@Component({
  selector: 'app-adminsignup',
  templateUrl: './adminsignup.component.html',
  styleUrls: ['./adminsignup.component.css']
})
export class AdminsignupComponent implements OnInit {

myForm:FormGroup;
feedback;
notallow;
messege;
msg;
  constructor(private fb:FormBuilder,private login:LoginService,private router:Router) { }

  adminsignup(){
  	let formData=this.myForm.getRawValue();
  	let confirmpass=this.myForm.controls.confirmpass.value;
  	let password=this.myForm.controls.password.value;
  	let key=this.myForm.controls.key.value;
  	if (confirmpass!=password){
  		this.feedback="no";
  		this.messege="Confirm password and password do not match"
  	}

  	if (key!="mikeshemous"){
  		this.feedback=null;
  		Swal.fire('Sorry','You do not have a security key','error' );
  	}
  	else{
  	this.login.adminsignup(formData)
  	.subscribe(res=>{
        console.log(res);
        Swal.fire('','Please Login to your account','success');
        this.router.navigate(['/']);

  	})
  }
}

  ngOnInit() {
  	this.validate();
  }


   validate()
  {
    this.myForm=this.fb.group(
      {
      	'name':['',Validators.required],
        'username':['',Validators.required],
        'password':['',Validators.required],
        'confirmpass':['',Validators.required],
        'email':['',Validators.required],
        'key':['',Validators.required]
      }
    )
  }

}
