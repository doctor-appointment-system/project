import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';
import {Router} from '@angular/router';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
myForm:FormGroup;
  constructor(private lser:LoginService,private router:Router,private fb:FormBuilder) { }
  feedback;
  userId;
  resData;
  msg;

 changePass()
  {

  	
    let op=this.myForm.controls.op.value;
    let np=this.myForm.controls.np.value;
    let cp=this.myForm.controls.cp.value;

    if (np!=cp){
      this.feedback="abc";
      this.msg="Old Password and new Password are not matching.";
    }
    else{

    this.userId=localStorage.getItem('username');
  //formData.append('email',this.userId)
   this.lser.changepass({'op':op,'np':np,'username':this.userId})
   .subscribe(res=>
   {
   
    this.resData=res;
    if (this.resData.err==1){
      Swal.fire('','Old Password is not correct','error')
    }
    else if (this.resData.err==0){
      Swal.fire('','Password has changed successfully','success');
      this.router.navigate(['/dashboard']);
   }
   })
  }
}


  ngOnInit() {
  this.validate();
  }

   validate()
   {
     this.myForm=this.fb.group({
       'op':['',Validators.required],
       'np':['',Validators.required],
       'cp':['',Validators.required]
     })
   }

}
