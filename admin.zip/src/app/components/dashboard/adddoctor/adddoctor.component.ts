import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoginService } from 'src/app/services/login.service';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-adddoctor',
  templateUrl: './adddoctor.component.html',
  styleUrls: ['./adddoctor.component.css']
})
export class AdddoctorComponent implements OnInit {
myForm:FormGroup;
  constructor(private fb:FormBuilder,private lser:LoginService,private router:Router) { }


  addDoctor(){
  	
  	  let formData=this.myForm.getRawValue();
  	  this.lser.adddoctor(formData)
  	  .subscribe(res=>{
                  console.log(res);
                  this.router.navigate(['/dashboard/doctor'])
  	  })
  }

  ngOnInit() {
  	this.validate();
  }

  validate()
  {
    this.myForm=this.fb.group(
      {
        'dname':['',Validators.required],
        'email':['',Validators.required]
      }
    )
  }

}
