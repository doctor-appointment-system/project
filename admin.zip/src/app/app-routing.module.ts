import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminloginComponent } from './components/adminlogin/adminlogin.component';
import { AdminsignupComponent } from './components/adminsignup/adminsignup.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ChangepasswordComponent } from './components/changepassword/changepassword.component';
import { DoctorComponent } from './components/dashboard/doctor/doctor.component';
import { AdddoctorComponent } from './components/dashboard/adddoctor/adddoctor.component';

const routes: Routes = [
{path:'',component:AdminloginComponent},
{path:'adminsignup',component:AdminsignupComponent},
{path:'dashboard',component:DashboardComponent,children:[
{path:'changepassword',component:ChangepasswordComponent},
{path:'doctor',component:DoctorComponent},
{path:'adddoctor',component:AdddoctorComponent}
]}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
