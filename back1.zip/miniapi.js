// All packages

const express=require('express');
const cors=require('cors');
const bodyParser=require('body-parser');
const sha1=require('sha1');
const mongoose=require('mongoose');
const nodemailer = require('nodemailer');

//Creating a database 

mongoose.connect("mongodb://localhost/mimiproject",{
	useCreateIndex:true,
	useNewUrlParser:true
});

let adminSignup=require('./databases/adminsignup');
let doctorModel=require('./databases/doctor');
let patientModel=require('./databases/patient');
let hospitalModel=require('./databases/hospital');


let app=express();
app.use(cors());
app.use(bodyParser.json());


  const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'karondiyan1999@gmail.com',
    pass: 'gulagula'
  }
});


//admin signup

app.post('/api/adminsignup',function(req,res){
  let name=req.body.name;
  let username=req.body.username;
  let email=req.body.email;
  let password=sha1(req.body.password);
  

   let ins=new adminSignup({'name':name,'email':email,'password':password,'username':username});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                   res.json({'err':0,'msg':'Account Created'});
                 }
           })


})


//admin login

app.post('/api/adminlogin',function(req,res){
	let username=req.body.username;
	let password=sha1(req.body.password);

	adminSignup.find({'username':username,'password':password},function(err,data){
		if (err){}
			else if (data.length==0){
				res.json({'err':1,'msg':'*username or password is not correct'});
			}
			else{
				res.json({'err':0,'msg':'Login Success','user':data});
			}
	})
})

app.post('/api/changepassword',function(req,res){

let username=req.body.username;
  let op=sha1(req.body.op);
  let np=sha1(req.body.np);

 

  adminSignup.find({'username':username},function(err,data){
    if (err){
    }
      else{
        let pass=data[0].password;
        if(op==pass){
adminSignup.update({'username':username},{$set:{'password':np}},function(err){
    if (err){
    }
      else{
        res.json({'err':0,'msg':'password change'});
      }
  })
}
else
{
  res.json({'err':1,'msg':'old password is not correct'});
}
      }
  })

  
})

app.post('/api/adddoctor',function(req,res){
  let name=req.body.dname;
  let email=req.body.email;
  let hospital=req.body.hospital;
   s=email.split("@");
   let username=s[0].toString();
    username=username+Math.floor(Math.random()*1000);
        let length=6;
      let password= '';
   let characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
   let charactersLength = characters.length;
   for (i = 0; i < length; i++ ) {
      password += characters.charAt(Math.floor(Math.random() * charactersLength));
   }
   let p=Math.floor(Math.random()*20)+password+Math.floor(Math.random()*20);
  password=sha1(p);


  let ins=new doctorModel({'name':name,'email':email,'password':password,'username':username,'hospital':hospital});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                            let mailOptions = {
                   from: 'karondiyan1999@gmail.com',
                   to: email,
                   subject: 'Added to DPAS 2019',
                   text: 'Hello!! I am sending a to notify you that you have been added to DPAS,\n your username is '+username +' and password is '+p+'\n'+'Thank you'
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
    res.json({'err':1,'msg':'Not send'});
  } else {
    console.log('Email sent: ' + info.response);
    res.json({'err':0,'msg':'Send Successfully'});
  }
});
                 }
           })


})


app.get('/api/showdoctor',function(req,res){

  doctorModel.find({},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'ddata':data});
      }
  })
})


//doctor login

app.post('/api/doctorlogin',function(req,res){
  let username=req.body.username;
  let password=sha1(req.body.password);
  
  doctorModel.find({'username':username,'password':password},function(err,data){
    if (err){
      console.log(err)
    }
      else if (data.length==0){

        res.json({'err':1,'msg':'*username or password is not correct'});
      }
      else{
        res.json({'err':0,'msg':'Login Success','user':data});
      }
  })
})


// patient signup

app.post('/api/patientsignup',function(req,res){
  let name=req.body.name;
  let email=req.body.email;
  let password=(req.body.password);
  let p=sha1(password)
  let mobile=req.body.mobile;

  console.log(name+" "+email+" ")


  

   let ins=new patientModel({'name':name,'email':email,'password':p,'mobile':mobile});
           ins.save(function(err)
           {
               if(err){
                console.log(err);
               }
               else
               {
                console.log("hii");
                res.json({'err':0,'msg':'saved Successfully'});
                   let mailOptions = {
                   from: 'karondiyan1999@gmail.com',
                   to: email,
                   subject: 'Registration In DPAS',
                   text: 'THANK YOU !! for register yourself as a patient in our project, \n you password is '+password
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
    res.json({'err':1,'msg':'Not send'});
  } else {
    console.log('Email sent: ' + info.response);
    res.json({'err':0,'msg':'Send Successfully'});
  }
});
                 }
           })


})


//patient login

app.post('/api/patientlogin',function(req,res){
  let username=req.body.username;
  let password=sha1(req.body.password);

  patientModel.find({'email':username,'password':password},function(err,data){
    if (err){}
      else if (data.length==0){
        res.json({'err':1,'msg':'*username or password is not correct'});
      }
      else{
        res.json({'err':0,'msg':'Login Success','user':data});
      }
  })
})









//add hospital in db

app.post('/api/addhospital',function(req,res){
  let name=req.body.hname;
  let address=req.body.address;
  let mobile=req.body.mobile;
   
  


  let ins=new hospitalModel({'name':name,'address':address,'mobile':mobile});
           ins.save(function(err)
           {
               if(err){}
               else
               {
                       res.json({'err':0,'msg':' added Successfully'});     
                 }
           })


})




//show hospital

app.get('/api/showhospital',function(req,res){

  hospitalModel.find({},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'ddata':data});
      }
  })
})



//fetch doctors of selected hospitals 
app.get('/api/fetchdoctor/:hname',function(req,res){
   let hname=req.params.hname;
   console.log(hname);
  doctorModel.find({'hospital':hname},function(err,data){
    if (err){}
      else{
        console.log(data.length);
        res.json({'err':0,'ddata':data});
      }
  })
})

app.get('/api/fetchdid/:did',function(req,res){
   let did=req.params.did;
  doctorModel.find({'username':did},function(err,data){
    if (err){}
      else{
        res.json({'err':0,'cdata':data});
      }
  })
})


//edit profile

app.post('/api/edit/:eid',function(req,res){
  let eid=req.params.eid;
  let name=req.body.name;
  let education=req.body.education;
  let mobile=req.body.mobile;
  let idnumber=req.body.idnumber;
  let stime=req.body.stime;
  let etime=req.body.etime;
  let spec=req.body.spec;

  let time=stime+'to'+etime;

  console.log(eid+" "+name+" "+education+" "+mobile+" "+idnumber+" "+stime+" "+etime+" "+spec);

  
                

                doctorModel.update({'username':eid},{$set:{'education':education,'mobile':mobile,'id':idnumber,'specilization':spec,'meetingtime':time}},function(err){
                  if (err){}
                    else{
                      console.log("profile changed");
                    }
                })
              
          
})

//profile

app.get('/api/profile/:eid',function(req,res){
  let eid=req.params.eid;

  doctorModel.find({'username':eid},function(err,data){
         if (err){}
          else{
            res.json({'err':0,'data':data});
          }
  })
})




app.listen(8080,function(){
	console.log("Works on 8080");
})

