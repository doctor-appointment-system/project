import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminloginComponent } from './components/adminlogin/adminlogin.component';
import { AdminsignupComponent } from './components/adminsignup/adminsignup.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ChangepasswordComponent } from './components/changepassword/changepassword.component';
import { DoctorComponent } from './components/dashboard/doctor/doctor.component';
import { AdddoctorComponent } from './components/dashboard/adddoctor/adddoctor.component';
import { HospitalComponent } from './components/dashboard/hospital/hospital.component';
import { AddhospitalComponent } from './components/dashboard/addhospital/addhospital.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminloginComponent,
    AdminsignupComponent,
    DashboardComponent,
    ChangepasswordComponent,
    DoctorComponent,
    AdddoctorComponent,
    HospitalComponent,
    AddhospitalComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
     ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
