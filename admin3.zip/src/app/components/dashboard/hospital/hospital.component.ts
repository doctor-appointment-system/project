import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';
// import {Router} from '@angular/router';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-hospital',
  templateUrl: './hospital.component.html',
  styleUrls: ['./hospital.component.css']
})
export class HospitalComponent implements OnInit {
resData;
data;
  constructor(private lser:LoginService) { }

  ngOnInit() {
  	this.lser.showHospital()
  	.subscribe(res=>{
  		this.resData=res;
  		this.data=this.resData.ddata;

  	})
  }

}
