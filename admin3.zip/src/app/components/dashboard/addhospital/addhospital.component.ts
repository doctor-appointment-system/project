import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LoginService } from 'src/app/services/login.service';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-addhospital',
  templateUrl: './addhospital.component.html',
  styleUrls: ['./addhospital.component.css']
})
export class AddhospitalComponent implements OnInit {
myForm:FormGroup;
resData;
  constructor(private fb:FormBuilder,private lser:LoginService,private router:Router) { }


addHospital(){
  	
  	  let formData=this.myForm.getRawValue();
  	  this.lser.addhospital(formData)
  	  .subscribe(res=>{
                  console.log(res);
                  this.resData=res
                  if(this.resData.err==0){
                  	Swal.fire("congrats","Added successfully","success");
                  this.router.navigate(['/dashboard/hospital'])
              }
  	  })
  }


  ngOnInit() {
  	this.validate();
  }

  validate()
  {
    this.myForm=this.fb.group(
      {
        'hname':['',Validators.required],
        'address':['',Validators.required],
        'mobile':['',Validators.required]
      }
    )
  }

}
