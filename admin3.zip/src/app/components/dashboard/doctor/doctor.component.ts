import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';
import {Router} from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']
})
export class DoctorComponent implements OnInit {
resData;
data;
  constructor(private lser:LoginService) { }

  ngOnInit() {
  	this.lser.showdoctor()
  	.subscribe(res=>{
  		this.resData=res;
  		this.data=this.resData.ddata;

  	})

  }

}
