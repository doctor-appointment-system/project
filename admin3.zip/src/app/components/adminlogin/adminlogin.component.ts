import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators} from '@angular/forms';
import { LoginService } from 'src/app/services/login.service';
import Swal from 'sweetalert2';
import {Router} from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

myForm:FormGroup;
username;
resData;

  constructor(private fb:FormBuilder ,private login:LoginService, private router:Router) { }

  adminlogin(){
  	let formData=this.myForm.getRawValue();
  	this.login.adminlogin(formData)
  	.subscribe(res=>{
  		this.resData=res;
  		if (this.resData.err==0){
  			localStorage.setItem('username',this.resData.user[0].username);
  			localStorage.setItem('name',this.resData.user[0].name);
  			this.router.navigate(['/dashboard']);
  		}
  	})
  }

  ngOnInit() {
  	this.validate();

  }

  validate()
  {
    this.myForm=this.fb.group(
      {
        'username':['',Validators.required],
        'password':['',Validators.required]
      }
    )
  }

}
