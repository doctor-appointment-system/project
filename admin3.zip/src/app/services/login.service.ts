import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

	url="http://localhost:8080/api/";

  constructor(private http:HttpClient) { }

  adminsignup(data){
  	return this.http.post(this.url+'adminsignup',data);
  }

  adminlogin(data){
  	return this.http.post(this.url+'adminlogin',data);
  }

  changepass(data){

    return this.http.post(this.url+'changepassword',data);
  }

  adddoctor(data){
    return this.http.post(this.url+'adddoctor',data);
  }

  showdoctor(){
    return this.http.get(this.url+'showdoctor');
  }

  addhospital(data){
    return this.http.post(this.url+'addhospital',data);
  }


  showHospital(){
    return this.http.get(this.url+'showhospital');
  }

}
